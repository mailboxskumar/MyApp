package PECOCMEPFileTrimmer;

import com.univocity.parsers.common.*;
import com.univocity.parsers.common.processor.*;
import com.univocity.parsers.csv.*;
import java.io.*;
import java.util.*;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javax.swing.JOptionPane;
import javax.swing.JProgressBar;

public class CMEPTrimmer {
	static class MeterSearch extends RowListProcessor {
		private final String sMatch;
		private final String cMatch;
		private int iMatch = -1;

		public MeterSearch(String cMatch, String sMatch) {
			this.cMatch = cMatch;
			this.sMatch = sMatch.toLowerCase();
		}

		public MeterSearch(int cMatch, String sMatch) {
			this(sMatch, null);
			iMatch = cMatch;
		}

		@Override
		public void rowProcessed(String[] row, ParsingContext context) {
			if (iMatch == -1) {
				iMatch = context.indexOf(cMatch);
			}

			String value = row[iMatch];
			if (value != null && value.toLowerCase().contains(sMatch)) {
				super.rowProcessed(row, context);
			}

		}
	}


	public void main(String MeterPath, String CMEPProd, String CMEPTrimmed) throws IOException {
		String sMeterNumber = new String();
		String excelFilePath = MeterPath;
		FileInputStream inputStream = new FileInputStream(new File(excelFilePath));

		Workbook workbook = new XSSFWorkbook(inputStream);
		Sheet firstSheet = workbook.getSheetAt(0);
		Iterator<Row> iterator = firstSheet.iterator();
		String outputFile = CMEPTrimmed;

		long start = System.currentTimeMillis();
		CsvWriterSettings writersettings = new CsvWriterSettings();
		CsvWriter writer = new CsvWriter(new FileWriter(CMEPTrimmed), new CsvWriterSettings());

		int rowCnt = firstSheet.getPhysicalNumberOfRows();
		System.out.println(rowCnt);

		JOptionPane.showMessageDialog(null,
				"Meters to Trim: " + (rowCnt - 1) + "\nEstimated time: " + ((rowCnt - 1) * 1) / 600 + " minutes",
				"PECO CMEP Trimmer Estimates ", JOptionPane.INFORMATION_MESSAGE);

		for (int i = 0; i <= rowCnt; i++) {

			while (iterator.hasNext()) {
				Row nextRow = iterator.next();
				Iterator<Cell> cellIterator = nextRow.cellIterator();

				while (cellIterator.hasNext()) {
					Cell cell = cellIterator.next();
					sMeterNumber = cell.getStringCellValue();
					System.out.println(sMeterNumber);

					CsvParserSettings settings = new CsvParserSettings();
					settings.setHeaders("1", "2", "3", "4", "5", "6", "7", "8", "9", "10");
					settings.setHeaderExtractionEnabled(true);

					MeterSearch search = new MeterSearch("6", sMeterNumber);
					// We instruct the parser to send all rows parsed to your custom RowProcessor.
					settings.setProcessor(search);

					// Finally, we create a parser
					CsvParser parser = new CsvParser(settings);

					parser.parse(new File(CMEPProd));
					List<String[]> results = search.getRows();
					System.out.println("Rows matched : " + results.size());
					System.out.println("Time taken: " + (System.currentTimeMillis() - start) + " ms");

					int size = results.size();
					if (size > 0) {
						System.out.println(sMeterNumber);
						writer.writeStringRows(results);

					}
				}
			}

		}
		writer.close();
		workbook.close();
		System.out.println("Completed");
		JOptionPane.showMessageDialog(null, "CMEP File trim is completed ", "PECO CMEP Trimmer Status",
				JOptionPane.INFORMATION_MESSAGE);
		
	}

};
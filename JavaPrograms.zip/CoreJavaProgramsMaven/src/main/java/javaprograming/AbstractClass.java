package javaprograming;

public abstract class AbstractClass {

}
